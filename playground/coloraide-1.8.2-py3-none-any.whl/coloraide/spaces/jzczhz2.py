"""
JzCzhz class.

https://www.osapublishing.org/oe/fulltext.cfm?uri=oe-25-13-15131&id=368272
"""
from __future__ import annotations
from ..spaces import Space, LChish
from ..cat import WHITES
from ..channels import Channel, FLG_ANGLE
from .. import util
import math
from .. import algebra as alg
from ..types import Vector
from .srgb_linear import lin_srgb_to_xyz
from .srgb import lin_srgb
from .jzazbz import xyz_d65_to_jzazbz
import bisect

ACHROMATIC_THRESHOLD = 0.0003
# The transform consistently yields ~216 for achromatic hues for positive lightness
# Replacing achromatic NaN hues with this hue gives us closer translations back.
ACHROMATIC_HUE = 216.0777045520467


def jzazbz_to_jzczhz(jzazbz: Vector) -> Vector:
    """Jzazbz to JzCzhz."""

    jz, az, bz = jzazbz

    cz = math.sqrt(az ** 2 + bz ** 2)
    hz = math.degrees(math.atan2(bz, az))

    # Achromatic colors will often get extremely close, but not quite hit zero.
    # Essentially, we want to discard noise through rounding and such.
    # if cz < ACHROMATIC_THRESHOLD:
    #     hz = alg.NaN

    return [jz, cz, util.constrain_hue(hz)]


def jzczhz_to_jzazbz(jzczhz: Vector) -> Vector:
    """JzCzhz to Jzazbz."""

    jz, cz, hz = jzczhz

    # # For better round tripping of achromatic colors,
    # # use the achromatic hue that occurs in forward transform.
    # # We use the one from white translation. It may vary slightly
    # # depending on the grayscale color, but only slightly,
    # # so this is close enough.
    # if cz < ACHROMATIC_THRESHOLD:
    #     hz = ACHROMATIC_HUE

    if alg.is_nan(hz):  # pragma: no cover
        return [jz, 0.0, 0.0]

    return [
        jz,
        cz * math.cos(math.radians(hz)),
        cz * math.sin(math.radians(hz))
    ]


class Achromatic:
    """
    Test if color is achromatic.

    Should work quite well through the SDR range. Can reasonably handle HDR range out to 3
    which is far enough for anything practical.

    We use a spline mainly to quickly fit the line in a way we do not have to analyze and tune.
    """

    CONVERTER = staticmethod(jzazbz_to_jzczhz)
    L_IDX = 0
    C_IDX = 1
    H_IDX = 2

    def __init__(
        self,
        tuning: dict[str, tuple[int, int, int, float]],
        threshold: float,
        spline: str
    ) -> None:
        """Initialize."""

        self.threshold = threshold

        # Create a spline that maps the achromatic range for the SDR range
        points = []  # type: list[list[float]]
        self.domain = []  # type: list[float]
        self.max_colorfulness = 1e-10
        self.spline = None
        self.iter_achromatic_response(points, *tuning['low'])
        self.iter_achromatic_response(points, *tuning['mid'])
        self.iter_achromatic_response(points, *tuning['high'])
        self.max_colorfulness = round(self.max_colorfulness, 3) + 1
        self.spline = alg.interpolate(points, method=spline)
        # Transform seems to favor a particular achromatic hue, capture the one at white
        # to replace achromatic NaN hues with.
        self.hue = self.CONVERTER(xyz_d65_to_jzazbz(lin_srgb_to_xyz(lin_srgb([1] * 3))))[self.H_IDX]
        print(len(points))

    def iter_achromatic_response(
        self,
        points: list[list[float]],
        start: int,
        end: int,
        step: int,
        scale: float
    ) -> None:
        """
        Iterate the achromatic response of the space.

        Save points of lightness vs colorfulness. Also, track the domain.
        """

        for p in range(start, end, step):
            c = self.CONVERTER(xyz_d65_to_jzazbz(lin_srgb_to_xyz(lin_srgb([p / scale] * 3))))
            j, m = c[self.L_IDX], c[self.C_IDX]
            if m > self.max_colorfulness:
                self.max_colorfulness = m
            self.domain.append(j)
            points.append([j, m])

    def scale(self, point: float) -> float:
        """Scale the lightness to match the range."""

        if point <= self.domain[0]:
            point = (point - self.domain[0]) / (self.domain[-1] - self.domain[0])
        elif point >= self.domain[-1]:
            point = 1.0 + (point - self.domain[-1]) / (self.domain[-1] - self.domain[0])
        else:
            regions = len(self.domain) - 1
            size = (1 / regions)
            index = 0
            adjusted = 0.0
            index = bisect.bisect(self.domain, point) - 1
            a, b = self.domain[index:index + 2]
            l = b - a
            adjusted = ((point - a) / l) if l else 0.0
            point = size * index + (adjusted * size)
        return point

    def get_ideal_chroma(self, j: float, m: float) -> float:
        """Get the ideal chroma."""

        if j < 0.0:  # pragma: no cover
            return 0.0

        if self.spline is not None:
            point = self.scale(j)
            m2 = self.spline(point)[1]
            if abs(m2 - m) < self.threshold:
                return m
            elif m < m2:
                return m2

        # This would be for `discounting=True`,
        # which we do not run with currently.
        return m  # pragma: no cover

    def test(self, j: float, m: float) -> bool:
        """Test if the current color is achromatic."""

        # If colorfulness is past this limit, we'd have to have a lightness
        # so high, that our test has already broken down.
        if m > self.max_colorfulness:
            return False

        # This is for when "discounting" as colorfulness should be very near zero
        if self.spline is None:  # pragma: no cover
            return True

        # If we are higher than 1, we are extrapolating;
        # otherwise, use the spline.
        point = self.scale(j)
        if point < 0:  # pragma: no cover
            m2 = 0.0
        else:
            m2 = self.spline(point)[1]
        return m < m2 or abs(m2 - m) < self.threshold


class JzCzhz(LChish, Space):
    """
    JzCzhz class.

    https://www.osapublishing.org/oe/fulltext.cfm?uri=oe-25-13-15131&id=368272
    """

    BASE = "jzazbz"
    NAME = "jzczhz"
    SERIALIZE = ("--jzczhz",)
    CHANNELS = (
        Channel("jz", 0.0, 1.0, limit=(0.0, None)),
        Channel("cz", 0.0, 0.5, limit=(0.0, None)),
        Channel("hz", 0.0, 360.0, flags=FLG_ANGLE)
    )
    CHANNEL_ALIASES = {
        "lightness": "jz",
        "chroma": "cz",
        "hue": "hz"
    }
    WHITE = WHITES['2deg']['D65']
    DYNAMIC_RANGE = 'hdr'

    # Achromatic detection
    ACHROMATIC = Achromatic(
        {
            'low': (0, 100, 5, 100.0),
            'mid': (100, 300, 10, 100.0),
            'high': (300, 520, 20, 100.0)
        },
        1.6e-06,
        'catrom'
    )

    def achromatic_hue(self) -> float:
        """Ideal achromatic hue."""

        return ACHROMATIC_HUE

    def hue_name(self) -> str:
        """Hue name."""

        return "hz"

    def to_base(self, coords: Vector) -> Vector:
        """To Jzazbz from JzCzhz."""

        j, c = coords[:2]
        if self.ACHROMATIC.test(j, c):
            coords[1] = self.ACHROMATIC.get_ideal_chroma(j, c)
            coords[2] = self.ACHROMATIC.hue

        return jzczhz_to_jzazbz(coords)

    def from_base(self, coords: Vector) -> Vector:
        """From Jzazbz to JzCzhz."""

        coords = jzazbz_to_jzczhz(coords)
        j, c = coords[:2]
        if self.ACHROMATIC.test(j, c):
            coords[2] = alg.NaN
        return coords
