"""Delta E OK."""
from ..distance import DeltaE, distance_euclidean


class DEOK(DeltaE):
    """Delta E OK class."""

    @staticmethod
    def name():
        """Name of method."""

        return "ok"

    @staticmethod
    def distance(color, sample, **kwargs):
        """Delta E OK color distance formula."""

        return distance_euclidean(color, sample, space="oklab")
