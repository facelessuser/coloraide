"""
HSLuv.

Adapted to Python and ColorAide by Isaac Muse (2021)

--- License ---

Copyright (c) 2012-2021 Alexei Boronine
Copyright (c) 2016 Florian Dormont

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""
from ..spaces import Space, RE_DEFAULT_MATCH, Angle, Percent, GamutBound, Cylindrical
from .lchuv_d65 import LchuvD65
from .lch.base import ACHROMATIC_THRESHOLD
from .lab.base import EPSILON, KAPPA
from .srgb.base import XYZ_TO_RGB
from .. import util
import re
import math


def distance_line_from_origin(line):
    """Distance line from origin."""

    return abs(line['intercept']) / math.sqrt(line['slope'] ** 2 + 1)


def length_of_ray_until_intersect(theta, line):
    """Length of ray until intersect."""

    return line['intercept'] / (math.sin(theta) - line['slope'] * math.cos(theta))


def get_bounds(l):
    """Get bounds."""

    result = []
    sub1 = ((l + 16) ** 3) / 1560896
    sub2 = sub1 if sub1 > EPSILON else l / KAPPA

    g = 0
    while g < 3:
        c = g
        g += 1
        m1, m2, m3 = XYZ_TO_RGB[c]
        g1 = 0
        while g1 < 2:
            t = g1
            g1 += 1
            top1 = (284517 * m1 - 94839 * m3) * sub2
            top2 = (838422 * m3 + 769860 * m2 + 731718 * m1) * l * sub2 - (769860 * t) * l
            bottom = (632260 * m3 - 126452 * m2) * sub2 + 126452 * t
            result.append({'slope': top1 / bottom, 'intercept': top2 / bottom})
    return result


def max_safe_chroma_for_l(l):
    """Get safe max chroma for lightness."""

    return min(distance_line_from_origin(bound) for bound in get_bounds(l))


def max_chroma_for_lh(l, h):
    """Get max from for l * h."""

    hrad = math.radians(h)
    lengths = [length_of_ray_until_intersect(hrad, bound) for bound in get_bounds(l)]
    return min(length for length in lengths if length >= 0)


def hsluv_to_lch(hsluv):
    """Convert HSLuv to Lch."""

    h, s, l = hsluv
    h = util.no_nan(h)
    c = 0
    if l > 100 - 1e-7:
        l = 100
    elif l < 1e-08:
        l = 0
    else:
        _hx_max = max_chroma_for_lh(l, h)
        c = _hx_max / 100 * s
        if c < ACHROMATIC_THRESHOLD:
            h = util.NaN
    return [l, c, util.constrain_hue(h)]


def lch_to_hsluv(lch):
    """Convert Lch to HSLuv."""

    l, c, h = lch
    h = util.no_nan(h)
    s = 0
    if l > 100 - 1e-7:
        l = 100
    elif l < 1e-08:
        l = 0
    else:
        _hx_max = max_chroma_for_lh(l, h)
        s = c / _hx_max * 100
    if s < 1e-08:
        h = util.NaN
    return [util.constrain_hue(h), s, l]


class HSLuv(Cylindrical, Space):
    """HSLuv class."""

    SPACE = "hsluv"
    SERIALIZE = ("--hsluv",)
    CHANNEL_NAMES = ("h", "s", "l", "alpha")
    CHANNEL_ALIASES = {
        "hue": "h",
        "saturation": "s",
        "lightness": "l"
    }
    DEFAULT_MATCH = re.compile(RE_DEFAULT_MATCH.format(color_space='|'.join(SERIALIZE), channels=3))
    WHITE = "D65"
    GAMUT_CHECK = "srgb"

    RANGE = (
        GamutBound([Angle(0.0), Angle(360.0)]),
        GamutBound([Percent(0.0), Percent(100.0)]),
        GamutBound([Percent(0.0), Percent(100.0)])
    )

    @property
    def h(self):
        """Hue channel."""

        return self._coords[0]

    @h.setter
    def h(self, value):
        """Shift the hue."""

        self._coords[0] = self._handle_input(value)

    @property
    def s(self):
        """Saturation channel."""

        return self._coords[1]

    @s.setter
    def s(self, value):
        """Saturate or unsaturate the color by the given factor."""

        self._coords[1] = self._handle_input(value)

    @property
    def l(self):
        """Lightness channel."""

        return self._coords[2]

    @l.setter
    def l(self, value):
        """Set lightness channel."""

        self._coords[2] = self._handle_input(value)

    @classmethod
    def null_adjust(cls, coords, alpha):
        """On color update."""

        if coords[1] == 0:
            coords[0] = util.NaN
        return coords, alpha

    @classmethod
    def _to_xyz(cls, parent, hsluv):
        """To XYZ."""

        return LchuvD65._to_xyz(parent, hsluv_to_lch(hsluv))

    @classmethod
    def _from_xyz(cls, parent, xyz):
        """From XYZ."""

        lch = LchuvD65._from_xyz(parent, xyz)
        return lch_to_hsluv(lch)
