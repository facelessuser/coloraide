"""
Delta E Jz.
https://www.osapublishing.org/oe/fulltext.cfm?uri=oe-25-13-15131&id=368272
"""
import math
from ... import util

def distance(color1, color2, **kwargs):
    """Delta E Jz."""

    jz1, az1, bz1 = util.no_nan(color1.convert('jzazbz').coords())
    jz2, az2, bz2 = util.no_nan(color2.convert('jzazbz').coords())

    cz1 = math.sqrt(az1 ** 2 + bz1 ** 2)
    cz2 = math.sqrt(az2 ** 2 + bz2 ** 2)

    hz1 = math.degrees(math.atan2(bz1, az1))
    hz2 = math.degrees(math.atan2(bz2, az2))

    djz = jz2 - jz1
    dcz = cz2 - cz1
    dhz = 2 * math.sqrt(cz1 * cz2) * math.sin(math.radians((hz1 - hz2) / 2))

    return math.sqrt(djz ** 2 + dcz ** 2 + dhz ** 2)
