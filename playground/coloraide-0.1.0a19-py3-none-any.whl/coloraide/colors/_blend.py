"""
RGB blend modes.

https://www.w3.org/TR/compositing/#blending
"""
from .. import util
import math
from operator import itemgetter

SUPPORTED = frozenset(
    [
        'normal', 'multiply', 'darken', 'lighten', 'burn', 'dodge', 'screen',
        'overlay', 'hard-light', 'exclusion', 'difference', 'soft-light',
        'hue', 'saturation', 'luminosity', 'color'
    ]
)


def lum(rgb):
    """Get luminosity."""

    return 0.3 * rgb[0] + 0.59 * rgb[1] + 0.11 * rgb[2]


def clip_color(rgb):
    """Clip color."""

    l = lum(rgb)
    n = min(*rgb)
    x = max(*rgb)
    if n < 0:
        rgb = [l + (((c - l) * l) / (l - n)) for c in rgb]

    if x > 1:
        rgb = [l + (((c - l) * (1 - l)) / (x - l)) for c in rgb]

    return rgb


def set_lum(rgb, l):
    """Set luminosity."""

    d = l - lum(rgb)
    rgb = [c + d for c in rgb]
    return clip_color(rgb)


def sat(rgb):
    """Saturation."""

    return max(*rgb) - min(*rgb)


def set_sat(rgb, s):
    """Set saturation."""

    final = [0] * 3
    indices, rgb = zip(*sorted(enumerate(rgb), key=itemgetter(1)))
    rgb = list(rgb)
    if rgb[2] > rgb[0]:
        rgb[1] = (((rgb[1] - rgb[0]) * s) / (rgb[2] - rgb[0]))
        rgb[2] = s
    else:
        rgb[1] = 0
        rgb[2] = 0
    rgb[0] = 0
    for index, value in zip(indices, rgb):
        final[index] = value
    return final


def handle_nan(cb, cs):
    """Handle `NaN`."""

    value = None
    if util.is_nan(cb) and util.is_nan(cs):
        value = 0.0
    elif util.is_nan(cb):
        value = cs
    elif util.is_nan(cs):
        value = cb
    return value


def blend_normal(cb, cs):
    """Blend mode 'normal'."""

    return cs


def blend_multiply(cb, cs):
    """Blend mode 'multiply'."""

    return cb * cs


def blend_screen(cb, cs):
    """Blend mode 'screen'."""

    return cb + cs - (cb * cs)


def blend_darken(cb, cs):
    """Blend mode 'darken'."""

    return min(cb, cs)


def blend_lighten(cb, cs):
    """Blend mode 'lighten'."""

    return max(cb, cs)


def blend_dodge(cb, cs):
    """Blend mode 'dodge'."""

    if cb == 0:
        return 0
    elif cs == 1:
        return 1
    else:
        return min(1, cb / (1 - cs))


def blend_burn(cb, cs):
    """Blend mode 'burn'."""

    if cb == 1:
        return 1
    elif cs == 0:
        return 0
    else:
        return 1 - min(1, (1 - cb) / cs)


def blend_overlay(cb, cs):
    """Blend mode 'overlay'."""

    return blend_screen(cb, 2 * cs - 1) if cb >= 0.5 else blend_multiply(cb, cs * 2)


def blend_difference(cb, cs):
    """Blend mode 'difference'."""

    return abs(cb - cs)


def blend_exclusion(cb, cs):
    """Blend mode 'exclusion'."""

    return cb + cs - 2 * cb * cs


def blend_hard_light(cb, cs):
    """Blend mode 'hard-light'."""

    return blend_multiply(cb, cs * 2) if cs <= 0.5 else blend_screen(cb, 2 * cs - 1)


def blend_soft_light(cb, cs):
    """Blend mode 'soft-light'."""

    if cs <= 0.5:
        return cb - (1 - 2 * cs) * cb * (1 - cb)
    else:
        if cb <= 0.25:
            d = ((16 * cb - 12) * cb + 4) * cb
        else:
            d = math.sqrt(cb)
        return cb + (2 * cs - 1) * (d - cb)


def blend_hue(cb, cs):
    return set_lum(set_sat(cs, sat(cb)), lum(cb))


def blend_saturation(cb, cs):
    return set_lum(set_sat(cb, sat(cs)), lum(cb))


def blend_luminosity(cb, cs):
    return set_lum(cb, lum(cs))


def blend_color(cb, cs):
    return set_lum(cs, lum(cb))


class Blend:
    """Blend modes."""

    def blend(self, color, mode, *, space=None, out_space=None):
        """Blend colors using the specified blend mode."""

        space = "srgb" if space is None else space.lower()
        outspace = self.space() if out_space is None else out_space.lower()
        mode = mode.lower()
        color1 = self.convert(space) if self.space() != space else self.clone()
        color2 = color.convert(space) if color.space() != space else color.clone()

        if mode not in SUPPORTED:
            raise ValueError("'{}' is not a recognized blend mode".format(mode))

        cba = color2.alpha
        csa = color1.alpha
        a0 = csa + cba * (1.0 - csa)
        coords = []
        blender = globals()['blend_{}'.format(mode.replace('-', '_'))]
        if mode not in ('color', 'hue', 'saturation', 'luminosity'):
            for cb, cs in zip(color2.coords(), color1.coords()):
                value = handle_nan(cb, cs)
                if value is None:
                    value = blender(cb, cs)
                coords.append(csa * ((1 - cba) * cb + cba * value) + (1 - csa) * cba * cb)
        else:
            cb = color2.coords()
            cs = color1.coords()
            for cbv, value in zip(color2.coords(), blender(cb, cs)):
                coords.append(csa * ((1 - cba) * cbv + cba * value) + (1 - csa) * cba * cbv)

        color1.update(coords, a0)
        return color1.convert(outspace)
