"""
RLAB.

https://scholarworks.rit.edu/cgi/viewcontent.cgi?article=1153&context=article
"""
from coloraide.cat import WHITES
from coloraide.spaces.lab import Lab
from coloraide import util
from coloraide import algebra as alg
from coloraide.types import MutableVector, Matrix, MutableMatrix, Vector
from typing import Sequence, cast

R = [
    [1.9569, -1.1882, 0.2313],
    [0.3612, 0.6388, 0.0],
    [0.0, 0.0, 1.0000]
]

M = [
    [0.4002, 0.7076, -0.0808],
    [-0.2263, 1.1653, 0.0457],
    [0.0, 0.0, 0.9182]
    # [0.3897, 0.6890, -0.0787],
    # [-0.2298, 1.1834, 0.0464],
    # [0.0000, 0.0000, 1.0000]
]

print(alg.inv(M))

YN = 318.0  # D65 318 cd / m^2
D = 0.0
EXP = 2.3


def calc_a_lms(lms: Vector) -> MutableVector:
    """Calculate the various a matrix diagonal values."""

    a = []
    s = sum(lms)
    for c in lms:
        l = (3.0 * c) / s
        p = (1.0 + alg.nth_root(YN, 3) + l) / (1.0 + alg.nth_root(YN, 3) + 1.0 / l)
        a.append((p + D * (1.0 - p)) / c)
    return a


def calc_ram(white: Vector, inv: bool = False) -> MutableMatrix:
    """Calculate RAM."""

    xyz_w = util.xy_to_xyz(white)
    lms = alg.dot(M, xyz_w)
    print(xyz_w)
    print(lms)
    a_lms = calc_a_lms(lms)
    print('===div')
    # print(alg.divide(xyz_w))
    W = [[xyz_w[0], 1, 1], [1, xyz_w[1], 1], [1, 1, xyz_w[2]]]
    print(W)
    R = alg.dot(alg.inv(M), W)
    print(R)
    A = alg.diag(a_lms)
    print(A)
    ram = alg.dot(R, alg.dot(A, M))
    return alg.inv(ram) if inv else ram


def rlab_to_xyz(rlab: MutableVector, white: Vector) -> MutableVector:
    """RLAB to XYZ."""

    iram = calc_ram(white, True)

    l, a, b = rlab
    yr = l / 100
    xr = alg.npow((a / 430) + yr, EXP)
    zr = alg.npow(yr - (b / 170), EXP)
    return alg.dot(iram, [xr, alg.npow(yr, EXP), zr])


def xyz_to_rlab(xyz: MutableVector, white: Vector) -> MutableVector:
    """XYZ to RLAB."""

    ram = calc_ram(white)
    xyz_ref = alg.dot(ram, xyz)
    xr, yr, zr = [alg.nth_root(c, EXP) for c in xyz_ref]
    l = 100 * yr
    a = 430 * (xr - yr)
    b = 170 * (yr - zr)
    return [l, a, b]


class RLAB(Lab):
    """RLAB class."""

    BASE = 'xyz-d65'
    NAME = "rlab"
    SERIALIZE = ("--rlab",)
    WHITE = WHITES['2deg']['D65']

    @classmethod
    def to_base(cls, coords: MutableVector) -> MutableVector:
        """To XYZ from Hunter Lab."""

        return rlab_to_xyz(coords, cls.white())

    @classmethod
    def from_base(cls, coords: MutableVector) -> MutableVector:
        """From XYZ to Hunter Lab."""

        return xyz_to_rlab(coords, cls.white())
